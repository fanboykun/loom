'use client'

import { useState } from 'react'
import {
  ArrowUp,
  AtSign,
  ChevronDown,
  Code2,
  Folder,
  GitBranch,
  LayoutGrid,
  MessageSquare,
  Paperclip,
  Plus,
  Sparkles,
  SquareTerminal,
  WandSparkles,
} from 'lucide-react'

const suggestions = ['Explore the codebase', 'Catch me up', 'Plan a feature', 'Review my changes']

export default function Page() {
  const [activeView, setActiveView] = useState('Chat')
  const [prompt, setPrompt] = useState('')
  const [autoAccept, setAutoAccept] = useState(true)

  return (
    <main className="min-h-screen overflow-hidden bg-[#0c0d0f] text-[#f4f5f6] selection:bg-cyan-400/20">
      <header className="flex h-[72px] items-center justify-between border-b border-white/[0.08] px-5 sm:px-8">
        <div className="flex items-center gap-3">
          <div className="grid size-9 place-items-center rounded-xl border border-white/10 bg-white/[0.06] shadow-sm">
            <Sparkles className="size-4 text-cyan-300" />
          </div>
          <div>
            <h1 className="text-sm font-semibold tracking-[-0.01em]">New session</h1>
            <div className="mt-1 flex items-center gap-2 text-[11px] text-white/45">
              <span>test</span><span className="text-white/20">•</span><GitBranch className="size-3" /><span>master</span>
            </div>
          </div>
        </div>
        <nav aria-label="Workspace views" className="flex items-center gap-1 rounded-xl border border-white/10 bg-white/[0.04] p-1">
          {[
            { label: 'Chat', icon: MessageSquare },
            { label: 'Kanban', icon: LayoutGrid },
            { label: 'Canvas', icon: WandSparkles },
          ].map(({ label, icon: Icon }) => (
            <button key={label} onClick={() => setActiveView(label)} className={`flex items-center gap-2 rounded-lg px-3 py-2 text-xs transition ${activeView === label ? 'bg-white/[0.12] text-white shadow-sm' : 'text-white/45 hover:text-white/80'}`}>
              <Icon className="size-3.5" />{label}
            </button>
          ))}
        </nav>
      </header>

      <section className="relative flex min-h-[calc(100vh-72px)] flex-col items-center px-4 pb-10 pt-[15vh] sm:pt-[20vh]">
        <div className="pointer-events-none absolute left-1/2 top-24 h-80 w-[42rem] -translate-x-1/2 rounded-full bg-cyan-500/[0.035] blur-3xl" />
        <div className="relative w-full max-w-[700px]">
          <div className="mb-8 text-center">
            <div aria-hidden="true" className="relative mx-auto mb-6 size-20">
              <div className="hero-orbit hero-orbit-one" />
              <div className="hero-orbit hero-orbit-two" />
              <div className="absolute inset-0 grid place-items-center">
                <div className="hero-core grid size-12 place-items-center rounded-2xl border border-cyan-200/30 bg-cyan-300/[0.1]">
                  <WandSparkles className="size-5 text-cyan-200" />
                </div>
              </div>
              <span className="hero-node hero-node-one" />
              <span className="hero-node hero-node-two" />
              <span className="hero-node hero-node-three" />
            </div>
            <h2 className="text-3xl font-medium tracking-[-0.04em] text-white sm:text-[38px]">Turn ideas into momentum</h2>
            <p className="mx-auto mt-3 max-w-md text-sm leading-6 text-white/45">Bring a little context. We&apos;ll shape the next step together.</p>
          </div>

          <button className="mb-3 flex items-center gap-2 rounded-lg border border-white/10 bg-white/[0.05] px-3 py-2 text-sm text-white/75 transition hover:bg-white/[0.08]">
            <Folder className="size-4 text-white/55" /> <span>test</span><ChevronDown className="ml-8 size-3.5 text-white/35" />
          </button>

          <div className="overflow-hidden rounded-2xl border border-white/[0.14] bg-[#191b1e] shadow-[0_18px_70px_rgba(0,0,0,0.3)] focus-within:border-cyan-300/30">
            <textarea value={prompt} onChange={(event) => setPrompt(event.target.value)} placeholder="Ask anything... @ for files and agents" aria-label="Message composer" className="min-h-[126px] w-full resize-none bg-transparent px-4 py-4 text-sm text-white outline-none placeholder:text-white/35" />
            <div className="flex flex-wrap items-center gap-1 border-t border-white/[0.07] px-3 py-2">
              <button aria-label="Add attachment" className="grid size-8 place-items-center rounded-lg text-white/55 hover:bg-white/[0.08] hover:text-white"><Plus className="size-4" /></button>
              <button aria-label="Attach file" className="grid size-8 place-items-center rounded-lg text-white/55 hover:bg-white/[0.08] hover:text-white"><Paperclip className="size-4" /></button>
              <button onClick={() => setAutoAccept(!autoAccept)} className="ml-1 flex items-center gap-2 rounded-lg px-2 py-1.5 text-xs text-white/50 hover:bg-white/[0.06]">
                <span className={`relative h-4 w-7 rounded-full transition ${autoAccept ? 'bg-cyan-300/80' : 'bg-white/20'}`}><span className={`absolute top-0.5 size-3 rounded-full bg-white transition ${autoAccept ? 'left-3.5' : 'left-0.5'}`} /></span> Auto-accept
              </button>
              <div className="ml-auto flex items-center gap-1">
                <button className="hidden items-center gap-2 rounded-lg px-2 py-1.5 text-xs text-white/65 hover:bg-white/[0.06] sm:flex"><Code2 className="size-3.5" /> opencode / Muse Spark 1.3 Free <ChevronDown className="size-3" /></button>
                <button className="flex items-center gap-2 rounded-lg px-2 py-1.5 text-xs text-white/65 hover:bg-white/[0.06]">build <ChevronDown className="size-3" /></button>
                <button className="hidden items-center gap-2 rounded-lg px-2 py-1.5 text-xs text-white/65 hover:bg-white/[0.06] sm:flex">BACKEND <ChevronDown className="size-3" /></button>
                <button aria-label="Send message" className="grid size-9 place-items-center rounded-full bg-white/65 text-[#191b1e] transition hover:bg-white" onClick={() => setPrompt('')}><ArrowUp className="size-4" /></button>
              </div>
            </div>
          </div>
          <p className="mt-3 text-center text-[11px] text-white/35">Enter to send · Shift + Enter for a new line · Files attach from your project</p>
          <div className="mt-5 flex flex-wrap justify-center gap-2">
            {suggestions.map((suggestion) => <button key={suggestion} onClick={() => setPrompt(suggestion)} className="rounded-full border border-white/10 bg-white/[0.025] px-3.5 py-2 text-xs text-white/55 transition hover:border-white/20 hover:bg-white/[0.07] hover:text-white/80">{suggestion}</button>)}
          </div>
        </div>
      </section>
    </main>
  )
}
